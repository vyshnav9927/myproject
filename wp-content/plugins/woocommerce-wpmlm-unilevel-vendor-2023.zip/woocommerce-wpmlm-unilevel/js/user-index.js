
 
$(document).ready(function() {
    $('#user-dashboard-tabs').responsiveTabs({
        startCollapsed: 'accordion'
    });
    $('#both-genealogy-tab').responsiveTabs({
        startCollapsed: 'true'
    });
    $('#user-e-wallet-tab').responsiveTabs({
        startCollapsed: 'true'
    });
} );
  