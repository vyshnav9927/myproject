=== WP MLM Woocommerce - Unilevel Plan ===
Contributors: Infinite Open Source Solutions LLP (iOSS)
Tags: comments, spam
Requires at least: 4.0
Tested up to: 5.2
Requires PHP: 7.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html