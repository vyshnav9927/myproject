<div id="mlm-main-div">        
    <?php    
    wpmlm_admin_area();    
    ?>    
</div>